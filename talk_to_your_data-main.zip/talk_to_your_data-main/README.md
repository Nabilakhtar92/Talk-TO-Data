Get insights from your dataset, small or large.  Using PandasAI and a LLM.
Get your PandasAI api key here:  https://pandabi.ai.  You are going to need to store it in your environment for you to use the code and the app.
